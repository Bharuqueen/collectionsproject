package com.capgemini.parallelProject.bean;

public class Account {

	private long accountNo;
	private long balance;
	private String name;
	private String gender;
	private String mobileNo;
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(long accountNo, long balance, String name, String gender, String mobileNo) {
		super();
		this.accountNo = accountNo;
		this.balance = balance;
		this.name = name;
		this.gender = gender;
		this.mobileNo = mobileNo;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public long getBalance() {
		return balance;
	}
	public void setBalance(long balance) {
		this.balance = balance;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", balance=" + balance + ", name=" + name + ", gender=" + gender
				+ ", mobileNo=" + mobileNo + "]";
	}
	
}
