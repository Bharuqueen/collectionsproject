package com.capgemini.parallelProject.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.capgemini.parallelProject.bean.Account;
import com.capgemini.parallelProject.bean.Transaction;
import com.capgemini.parallelProject.exception.AccountException;

public interface AccountDao {

	
	
	//public long addAccount(Account account) throws AccountException;
	
	//public long addDeposit(Transaction transaction);
	public long deposit(long accountNumber, long depositedAmount);

	public long createTransaction(Transaction transaction);

	public long getBalance(long accountNo);

	public void addAccount(long accountNo, Account account);

	public long withdrawl(long accountNo, long amountWithdrawl);

	public long transaction(long senderAccountNo, long recieverAccountNo, long transferAmount);

	boolean addTraansaction(Transaction transaction) throws AccountException;

	public Set<Transaction> printTransaction() throws AccountException;
}
